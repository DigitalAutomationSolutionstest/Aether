# Sandbox aether_sandbox_20250720_053222

Creato automaticamente da Aether il 2025-07-20 05:32:22

## Struttura
- `src/` - Codice sorgente
- `tests/` - Test
- `data/` - Dati
- `main.py` - File principale

## Avvio
```bash
python main.py
```

## Installazione dipendenze
```bash
pip install -r requirements.txt
```
