// Sandbox JavaScript - Creato da Aether
console.log("🚀 Sandbox aether_sandbox_20250720_053046 caricato!");

function testFunction() {
    alert("✅ JavaScript funzionante! Sandbox creato da Aether il 2025-07-20 05:30:46");
}

// Auto-esecuzione
document.addEventListener('DOMContentLoaded', function() {
    console.log("📄 DOM caricato - Sandbox attivo!");
});
